# refbias — Overleaf 패키지 (Safety Science 투고본)

빌드 확인: 2026-09-19 (6차 패널 교정 + AI 문체 제거 반영) · main.pdf 39면 · supplement.pdf 8면 · 참고문헌 95건 · undefined 0건

## Overleaf 업로드

New Project → Upload Project → 이 zip 그대로 업로드.
평탄 구조이므로 폴더를 풀어서 올리지 말 것 (`fig/` 는 zip 안에 포함되어 있다).

## 컴파일러 설정

| 파일 | 컴파일러 | 비고 |
|---|---|---|
| `main.tex` | **pdfLaTeX** | 메인 원고. Menu → Compiler → pdfLaTeX |
| `supplement.tex` | **XeLaTeX** | 한글 표 포함. Menu → Compiler → XeLaTeX 로 바꾼 뒤 컴파일 |
| `cover_letter.tex` | pdfLaTeX | |
| `highlights.tex` | pdfLaTeX | |

Overleaf 는 프로젝트당 컴파일러가 하나다. `supplement.tex` 를 뽑을 때만 XeLaTeX 로 바꾸고,
끝나면 pdfLaTeX 로 되돌린다. 또는 supplement 를 별도 프로젝트로 올려도 된다.

`supplement.tex` 의 한글 폰트는 fallback 체인으로 되어 있다
(Noto Serif CJK KR → Noto Sans CJK KR → NanumMyeongjo → NanumBarunGothic → UnBatang).
Overleaf 에는 Noto CJK 가 있으므로 별도 설정 없이 컴파일된다.

## Editorial Manager 제출 파일

- Manuscript: `main.pdf` (또는 원고 원본으로 `main.tex` + `myref.bib`)
- Highlights: `highlights.pdf`
- Supplementary material: `supplement.pdf`
- Cover letter: `cover_letter.pdf`
- Figures: `fig/` 의 PDF 5개 (개별 업로드 요구 시)

Suggested Reviewers 는 공란으로 둔다. Safety Science 저자 안내에 요구 문구가 없다.

## 데이터·코드

https://github.com/bisu9082/refbias
