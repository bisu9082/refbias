# refbias — Overleaf 업로드 패키지 (투고본)

원고 v14 (2026-09-19). **자리표시자 없음. 투고 가능 상태.**
Overleaf 의 **New Project → Upload Project** 로 그대로 올리면 된다.

## 타깃 저널

International Journal of Disaster Risk Reduction (Elsevier). `elsarticle` 클래스, 행번호 켜짐.

## 파일 구성

| 파일 | 내용 | 컴파일러 |
|---|---|---|
| `main.tex` | 본문 원고 | **pdfLaTeX** |
| `supplement.tex` | 보충자료 S1–S12 (한글 데이터 포함) | **XeLaTeX** |
| `cover_letter.tex` | 편집장 커버레터 | pdfLaTeX |
| `highlights.tex` | Highlights 5개 항목 | pdfLaTeX |
| `myref.bib` | 참고문헌 88건 (DOI 전수 검증) | — |
| `elsarticle.cls`, `elsarticle-num-names.bst` | Elsevier 클래스·스타일 | — |
| `fig/Fig1–5_*.pdf` | 그림 5종 (벡터) | — |

## Overleaf 설정

1. Menu → **Main document** 를 `main.tex` 로.
2. 기본 컴파일러 **pdfLaTeX** 로 본문이 바로 빌드된다 (37쪽, 오류 0, 미정의 참조 0).
3. `supplement.tex` 빌드할 때만 Menu → Compiler → **XeLaTeX**.
   첫 줄에 `% !TeX program = XeLaTeX` 매직 코멘트가 있다.
   한글 글꼴은 Noto Serif CJK KR → Noto Sans CJK KR → NanumMyeongjo → NanumBarunGothic → UnBatang
   순으로 설치된 것을 자동으로 찾는다.

## 상태

- 본문 37쪽 (본문 29 + 참고문헌 7 + 선언), 보충자료 6쪽, 참고문헌 88편
- 미정의 참조·인용 **0건**
- 정합성 감사 **87/87** (자리표시자 0)
- 인용 DOI 88건 전수 확인, 허구 0건
- 공개 저장소: https://github.com/bisu9082/refbias (투고 전 push 필요)

## 투고 전 마지막 확인

- [ ] GitHub 저장소 `bisu9082/refbias` 를 public 으로 push
- [ ] 추천 심사위원 6인 이해충돌 최종 확인 (`추천심사위원_검증본.md`)
- [ ] Editorial Manager 에 main.pdf / supplement.pdf / cover_letter.pdf / highlights.pdf 업로드
