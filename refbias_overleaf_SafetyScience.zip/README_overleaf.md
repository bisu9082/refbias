# refbias — Overleaf 업로드 패키지 (투고본)

원고 v15 (2026-09-19). **타깃: Safety Science (Elsevier).** 자리표시자 없음.
Overleaf 의 **New Project → Upload Project** 로 그대로 올리면 된다.

## 왜 Safety Science 인가

IJDRR 은 Gold OA 전용으로 전환되어 구독(무료) 경로가 없고 APC 가 USD 2,760 이다.
Safety Science 는 하이브리드로 **구독 경로에 저자 부담이 없다** (OA 선택 시에만 APC).
참고문헌 방식도 번호 인용으로 동일해 서지 변환이 필요 없었다.

## 파일 구성

| 파일 | 내용 | 컴파일러 |
|---|---|---|
| `main.tex` | 본문 원고 | **pdfLaTeX** |
| `supplement.tex` | 보충자료 S1–S12 (한글 데이터 포함) | **XeLaTeX** |
| `cover_letter.tex` | 편집장 커버레터 | pdfLaTeX |
| `highlights.tex` | Highlights 5개 (각 85자 이하) | pdfLaTeX |
| `myref.bib` | 참고문헌 88건 (DOI 전수 검증) | — |
| `elsarticle.cls`, `elsarticle-num-names.bst` | Elsevier 클래스·스타일 | — |
| `fig/Fig1–5_*.pdf` | 그림 5종 (벡터) | — |

## Overleaf 설정

1. Menu → **Main document** 를 `main.tex` 로.
2. 기본 **pdfLaTeX** 로 본문 빌드 (37쪽, 오류 0, 미정의 참조 0).
3. `supplement.tex` 빌드할 때만 Menu → Compiler → **XeLaTeX**.

## Safety Science 규정 대조

- 참고문헌: 번호 인용 — **충족** (elsarticle-num-names)
- 초록: 250단어 이하 — **충족** (250)
- Highlights: 3–5개, 각 85자 이하 — **충족** (5개, 66–78자)
- 키워드: 1–7개 — **충족** (7)
- CRediT 저자 기여 진술 — **포함**
- Graphical abstract: 권장 — `figures/GA_refbias.png` 예치본에 있음

## 상태

- 미정의 참조·인용 0건 / 정합성 감사 87/87 / 자리표시자 0
- 공개 저장소: https://github.com/bisu9082/refbias
